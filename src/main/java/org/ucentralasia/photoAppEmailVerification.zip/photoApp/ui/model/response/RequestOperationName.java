package org.ucentralasia.photoApp.ui.model.response;

public enum RequestOperationName {
    DELETE, VERIFY_EMAIL
}