package org.ucentralasia.photoApp.exceptions;

public class UserServiceExceptions extends RuntimeException {
    public UserServiceExceptions(String message) {
        super(message);
    }
}