package org.ucentralasia.photoApp.ui.model.response;

public enum RequestOperationStatus {
    ERROR, SUCCESS;
}